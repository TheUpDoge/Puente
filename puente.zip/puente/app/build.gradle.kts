import java.net.URL

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "app.puente"
    compileSdk = 35

    defaultConfig {
        applicationId = "app.puente"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0-alpha"

        // Phones only: keeps the APK smaller (Vosk + JNA ship native libs for every ABI).
        ndk { abiFilters += listOf("arm64-v8a", "armeabi-v7a") }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.activity:activity-ktx:1.9.3")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-play-services:1.8.1")

    // Offline speech recognition (Apache-2.0). The model files are fetched by fetchVoskModels below.
    implementation("com.alphacephei:vosk-android:0.3.75")
    implementation("net.java.dev.jna:jna:5.13.0@aar")

    // Offline translation (free Google SDK, closed source). Hidden behind TextTranslator so it can be swapped.
    implementation("com.google.mlkit:translate:17.0.3")
}

// ---------------------------------------------------------------------------
// Offline speech models.
// Downloaded once into src/main/assets so the APK works with no internet for
// speech recognition. The "uuid" file tells Vosk when to re-unpack on device.
// To change/add a language, edit this map and the matching code in SpeechPipeline.
// ---------------------------------------------------------------------------
val voskModels = mapOf(
    "model-en" to "vosk-model-small-en-us-0.15",
    "model-es" to "vosk-model-small-es-0.42",
)

val fetchVoskModels by tasks.registering {
    group = "puente"
    description = "Downloads the offline Vosk speech models into src/main/assets (first build only)."
    val assetsDir = layout.projectDirectory.dir("src/main/assets").asFile
    doLast {
        voskModels.forEach { (dest, name) ->
            val target = File(assetsDir, dest)
            if (File(target, "uuid").exists()) return@forEach
            logger.lifecycle("Downloading speech model $name ...")
            val zip = File(temporaryDir, "$name.zip")
            URL("https://alphacephei.com/vosk/models/$name.zip").openStream().use { input ->
                zip.outputStream().use { out -> input.copyTo(out) }
            }
            target.deleteRecursively()
            copy {
                from(zipTree(zip)) {
                    // The zip has one top-level folder; drop it so files land directly in `target`.
                    eachFile { relativePath = RelativePath(true, *relativePath.segments.drop(1).toTypedArray()) }
                    includeEmptyDirs = false
                }
                into(target)
            }
            File(target, "uuid").writeText(name)
            zip.delete()
        }
    }
}

tasks.named("preBuild") { dependsOn(fetchVoskModels) }
